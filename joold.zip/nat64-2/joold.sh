sudo service network-manager stop
sudo modprobe -r jool
sudo modprobe -r jool_siit

sudo ip addr add 1::1/120 dev eth0
sudo ip link set eth0 up

sudo ip addr add 192.0.2.1/24 dev eth1
sudo ip link set eth1 up

sudo ip addr add 10.0.0.1/24 dev eth2
sudo ip link set eth2 up

sudo modprobe jool disabled
sudo jool -6a 64:ff9b::/96
sudo jool --enable
sudo jool --synch-enable

joold netsocket.json

