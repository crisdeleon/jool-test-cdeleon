sudo ip addr flush dev vboxnet0 scope global
sudo ip addr add 1::8/120 dev vboxnet0
sudo ip link set vboxnet0 up

sudo ip addr flush dev vboxnet1 scope global
sudo ip addr add 192.0.2.8/24 dev vboxnet1
sudo ip link set vboxnet1 up

sudo ip route add 64:ff9b::/96 via 1::1

